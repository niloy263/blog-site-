// src/pages/Login.js
import React from 'react';
import Menu from '../components/Menu';
import Footer from '../components/Footer';

const Login = () => {
    return (
        <div>
            <Menu />
            <h2>Login Page</h2>
            <Footer />
        </div>
    );
};

export default Login;
