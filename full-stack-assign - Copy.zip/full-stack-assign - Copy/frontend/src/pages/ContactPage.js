import React, { useState } from 'react';
import axios from 'axios';
import Menu from '../components/Menu';
import Footer from '../components/Footer';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('/api/contact', formData) // Adjust URL to your backend API
      .then(response => alert('Message sent successfully!'))
      .catch(error => console.error('Error sending message:', error));
  };

  return (
    <div>
      <Menu />
      <div className="contact-form">
        <h2>Contact Us</h2>
        <form onSubmit={handleSubmit}>
          <input type="text" name="name" placeholder="Your Name" onChange={handleChange} />
          <input type="email" name="email" placeholder="Your Email" onChange={handleChange} />
          <textarea name="message" placeholder="Your Message" onChange={handleChange}></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
      <Footer />
    </div>
  );
};

export default ContactPage;
