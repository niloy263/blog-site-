import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Menu from '../components/Menu';
import AboutSection from '../components/AboutSection';
import TeamSection from '../components/TeamSection';
import Footer from '../components/Footer';

const AboutPage = () => {
  const [teamMembers, setTeamMembers] = useState([]);

  useEffect(() => {
    axios.get('/api/teams') // Adjust the URL to match your backend API
      .then(response => setTeamMembers(response.data))
      .catch(error => console.error('Error fetching team members:', error));
  }, []);

  return (
    <div>
      <Menu />
      <AboutSection />
      <TeamSection teamMembers={teamMembers} />
      <Footer />
    </div>
  );
};

export default AboutPage;
