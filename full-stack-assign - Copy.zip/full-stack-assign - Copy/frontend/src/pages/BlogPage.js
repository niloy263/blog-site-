import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Menu from '../components/Menu';
import BlogSection from '../components/BlogSection';
import Footer from '../components/Footer';

const BlogPage = () => {
  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
    axios.get('/api/blogs') // Adjust the URL to match your backend API
      .then(response => setBlogs(response.data))
      .catch(error => console.error('Error fetching blogs:', error));
  }, []);

  return (
    <div>
      <Menu />
      <BlogSection blogs={blogs} />
      <Footer />
    </div>
  );
};

export default BlogPage;
