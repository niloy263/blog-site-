import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Menu from '../components/Menu';
import ServiceSection from '../components/ServiceSection';
import Footer from '../components/Footer';

const ServicePage = () => {
  const [services, setServices] = useState([]);

  useEffect(() => {
    axios.get('/api/services') // Adjust the URL to match your backend API
      .then(response => setServices(response.data))
      .catch(error => console.error('Error fetching services:', error));
  }, []);

  return (
    <div>
      <Menu />
      <ServiceSection services={services} />
      <Footer />
    </div>
  );
};

export default ServicePage;

