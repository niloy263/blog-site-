// src/components/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p className=' bg-secondary lg text-center'>&copy; 2024 Blog Website. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
