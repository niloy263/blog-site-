// src/components/CustomSection.js
import React from 'react';

const CustomSection = () => {
  return (
    <section className="custom-section mt-4">
      <h2>Our Special Features</h2>
      <p>Learn more about what makes our service unique.</p>
    </section>
  );
};

export default CustomSection;
