import React, { useState, useEffect } from 'react';
import axios from 'axios';

const TeamSection = () => {
  const [teamMembers, setTeamMembers] = useState([]);

  useEffect(() => {
    axios.get('/api/team')  // Adjust to your actual API endpoint
      .then(response => setTeamMembers(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <section className="team-section">
      <h2>Meet Our Team</h2>
      <div className="team-list">
        {teamMembers.map(member => (
          <div key={member._id} className="team-member">
            <img src={member.image} alt={member.name} />
            <h3>{member.name}</h3>
            <p>{member.position}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default TeamSection;
