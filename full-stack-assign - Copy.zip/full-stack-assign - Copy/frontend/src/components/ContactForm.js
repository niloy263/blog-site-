import React, { useState } from 'react';
import axios from 'axios';

const ContactForm = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = { name, email, message };
    
    axios.post('/api/contact', formData)  // Adjust to your actual API endpoint
      .then(response => {
        setStatus('Message sent successfully!');
        setName('');
        setEmail('');
        setMessage('');
      })
      .catch(error => {
        setStatus('Failed to send message. Please try again.');
      });
  };

  return (
    <section className="contact-form-section">
      <h2>Contact Us</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="Your Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <textarea
          placeholder="Your Message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          required
        ></textarea>
        <button type="submit">Send Message</button>
      </form>
      {status && <p>{status}</p>}
    </section>
  );
};

export default ContactForm;
