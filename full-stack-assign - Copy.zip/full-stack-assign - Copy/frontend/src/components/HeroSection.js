// src/components/HeroSection.js
import React from 'react';

const HeroSection = () => {
  return (
    <section className="hero bg-info lg text-center">
      <h1 className='mt-4'>Welcome to Our Website</h1>
      <p className='mt-3'>Your journey starts here</p>
      <button>Learn More</button>
    </section>
  );
};

export default HeroSection;
