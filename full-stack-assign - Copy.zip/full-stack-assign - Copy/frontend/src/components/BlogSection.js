import React, { useState, useEffect } from 'react';
import axios from 'axios';

const BlogSection = () => {
  const [blogs, setBlogs] = useState([]);

  useEffect(() => {
    axios.get('/api/blogs')  // Adjust to your actual API endpoint
      .then(response => setBlogs(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <section className="blog-section">
      <h2>Latest Blogs</h2>
      <div className="blog-list">
        {blogs.map(blog => (
          <div key={blog._id} className="blog-item">
            <h3>{blog.title}</h3>
            <p>{blog.content}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default BlogSection;
