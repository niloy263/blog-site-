import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AboutSection = () => {
  const [aboutContent, setAboutContent] = useState(null);

  useEffect(() => {
    axios.get('/api/about')  // Adjust to your actual API endpoint
      .then(response => setAboutContent(response.data))
      .catch(error => console.error(error));
  }, []);

  if (!aboutContent) return <div>Loading...</div>;

  return (
    <section className="about-section">
      <h2>{aboutContent.title}</h2>
      <p>{aboutContent.description}</p>
    </section>
  );
};

export default AboutSection;
