import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ServiceSection = () => {
  const [services, setServices] = useState([]);

  useEffect(() => {
    axios.get('/api/services')  // Adjust to your actual API endpoint
      .then(response => setServices(response.data))
      .catch(error => console.error(error));
  }, []);

  return (
    <section className="service-section">
      <h2>Our Services</h2>
      <div className="service-list">
        {services.map(service => (
          <div key={service._id} className="service-item">
            <h3>{service.name}</h3>
            <p>{service.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default ServiceSection;
