const express = require('express');
const Team = require('../models/Team');
const router = express.Router();

// Create Team Member
router.post('/', async (req, res) => {
  const { name, position, bio, imageUrl } = req.body;
  try {
    const newMember = new Team({ name, position, bio, imageUrl });
    await newMember.save();
    res.status(201).json(newMember);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get All Team Members
router.get('/', async (req, res) => {
  try {
    const members = await Team.find();
    res.json(members);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update Team Member
router.put('/:id', async (req, res) => {
  const { name, position, bio, imageUrl } = req.body;
  try {
    const updatedMember = await Team.findByIdAndUpdate(
      req.params.id,
      { name, position, bio, imageUrl },
      { new: true }
    );
    res.json(updatedMember);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete Team Member
router.delete('/:id', async (req, res) => {
  try {
    await Team.findByIdAndDelete(req.params.id);
    res.json({ message: 'Team member deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
