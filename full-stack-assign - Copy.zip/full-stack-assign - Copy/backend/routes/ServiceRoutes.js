const express = require('express');
const Service = require('../models/Service');
const router = express.Router();

// Create Service
router.post('/', async (req, res) => {
  const { title, description } = req.body;
  try {
    const newService = new Service({ title, description });
    await newService.save();
    res.status(201).json(newService);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Get All Services
router.get('/', async (req, res) => {
  try {
    const services = await Service.find();
    res.json(services);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Update Service
router.put('/:id', async (req, res) => {
  const { title, description } = req.body;
  try {
    const updatedService = await Service.findByIdAndUpdate(
      req.params.id,
      { title, description },
      { new: true }
    );
    res.json(updatedService);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Delete Service
router.delete('/:id', async (req, res) => {
  try {
    await Service.findByIdAndDelete(req.params.id);
    res.json({ message: 'Service deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
